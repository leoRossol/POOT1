public class Main {
    public static void main(String[] args) {
        ACMEDelivery app = new ACMEDelivery();

        // Defina os valores dos argumentos
        String filePOO = "filePOO.txt";
        

        
        app.executa( );
    }
}
